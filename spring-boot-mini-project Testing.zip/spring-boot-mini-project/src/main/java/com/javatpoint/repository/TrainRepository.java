package com.javatpoint.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.javatpoint.model.Train;

public interface TrainRepository extends CrudRepository<Train, Integer>
{
	@Query("select isAvailable from Train t ")
	List<String> Available();

}
