package com.javatpoint.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.javatpoint.model.Passenger;
import com.javatpoint.service.PassengerService;

@RestController
public class PassengerController
{
	@Autowired
	PassengerService passengerService;

	@GetMapping("/passengers")
	private List<Passenger> getAllPassenger()
	{
		return passengerService.getAllPassenger();
	}
	
	@GetMapping("/passengers/{passengerId}")
	private Passenger getPassenger(@PathVariable ("passengerId") Integer passengerId)
	{
		return passengerService.getPassengerById(passengerId);
	}
	
	@DeleteMapping("/passengers/{passengerId}")
	private String deletePassenger(@PathVariable("passengerId") Integer passengerId) 
	{
	passengerService.delete(passengerId);
	return "Deleted";
	}
	
	//creating post mapping 
	@PostMapping("/passengers")
	private String savePassenger(@RequestBody Passenger passenger) 
	{
	String s=passengerService.saveOrUpdate(passenger);
	return s;

	}
	
	//creating put mapping that updates detail 
	@PutMapping("/passengers")
	private String update(@RequestBody Passenger passenger) 
	{
	passengerService.saveOrUpdate(passenger);
	return "Updated";
	}
	
	@DeleteMapping("/passengers")
	private String deletePassengers(@RequestBody Passenger passenger) 
	{
	passengerService.deleteAll(passenger);
	return "Deleted";
	}
}
