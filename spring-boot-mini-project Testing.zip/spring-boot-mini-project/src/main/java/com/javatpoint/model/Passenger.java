package com.javatpoint.model;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.springframework.lang.NonNull;


@Entity

public class Passenger
{
	@Id
	@NonNull
	private Integer passengerId;
	private String passengerName;
	private int age;
	
	 @OneToMany(cascade={CascadeType.ALL})
	    private List<Ticket> ticket;
	
	public Passenger() 
	{
		
	}
	

	public Passenger(Integer passengerId, String passengerName, int age, List<Ticket> ticket) {
		super();
		this.passengerId = passengerId;
		this.passengerName = passengerName;
		this.age = age;
		this.ticket = ticket;
	}


	public Integer getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(Integer passengerId) {
		this.passengerId = passengerId;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public List<Ticket> getTicket() {
		return ticket;
	}

	public void setTicket(List<Ticket> ticket) {
		this.ticket = ticket;
	}


	@Override
	public String toString() {
		return "Passenger [passengerId=" + passengerId + ", passengerName=" + passengerName + ", age=" + age
				+ ", ticket=" + ticket + "]";
	}

 
	

	
}