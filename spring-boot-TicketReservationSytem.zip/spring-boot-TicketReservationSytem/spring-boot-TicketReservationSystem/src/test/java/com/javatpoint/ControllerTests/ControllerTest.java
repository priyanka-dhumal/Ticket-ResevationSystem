package com.javatpoint.ControllerTests;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.javatpoint.controller.PassengerController;
import com.javatpoint.model.Passenger;
import com.javatpoint.model.Ticket;
import com.javatpoint.model.Train;
import com.javatpoint.service.PassengerService;

@WebMvcTest(PassengerController.class)
@TestMethodOrder(OrderAnnotation.class)
class ControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	PassengerService passengerService;
	
	@Autowired
	ObjectMapper mapper= new ObjectMapper();
	
	
	@Test
	@Order(1)
	  public void save() throws Exception
	  {
		  Train train=new Train();
		  train.setTrainId(2);
		  train.setTrainSource("Pune");
		  train.setCapacity(24);
		  train.setIsAvailable("true");
		  train.setTrainDestination("Mumbai");
		  
		  
		  List<Train>t1=new ArrayList<Train>();
		  t1.add(train);
		  
		  Ticket t=new Ticket();
		  t.setTicketId(9);
		  t.setTicketAmount(200f);
		  t.setSource("Pune");
		  t.setSeatAllotted(3);
		  t.setPassenger_Id(3);
		  t.setDestination("Nagpur");
		  t.setArrivalDate("12/3/23");
		  t.setTravellingDate("12/3/23");
		  t.setTrain(t1);
		  
		  
		  List<Ticket> tir=new ArrayList<>();
		  tir.add(t);
		  

		  Passenger p=new Passenger();
		  p.setPassengerName("Aman");
	      p.setPassengerId(3);
		  p.setAge(26);
		  p.setTicket(tir);
		  

		  
		  when(passengerService.saveOrUpdate(Mockito.any(Passenger.class))).thenReturn("Booking done Succesfully");
		  
		  String json= mapper.writeValueAsString(p);
		  
		  RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/passengers")
		  .content(json)
		  .contentType(MediaType.APPLICATION_JSON);
		  MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk())
		  .andReturn();
		  
		  String actualResponseBody = mvcResult.getResponse().getContentAsString();
		  String expected="Booking done Succesfully";
		  assertThat(actualResponseBody).isEqualToIgnoringWhitespace(expected);

		  
	  }
	
	@Test
	@Order(2)
	public void getPassenger() throws Exception
	{
		Train train=new Train();
		  train.setTrainId(2);
		  train.setTrainSource("Pune");
		  train.setCapacity(24);
		  train.setIsAvailable("true");
		  train.setTrainDestination("Mumbai");
		 
		  
		  List<Train>t1=new ArrayList<Train>();
		  t1.add(train);
		  
		  Ticket t=new Ticket();
		  t.setTicketId(9);
		  t.setTicketAmount(200f);
		  t.setSource("Pune");
		  t.setSeatAllotted(3);
		  t.setPassenger_Id(3);
		  t.setDestination("Nagpur");
		  t.setArrivalDate("12/3/23");
		  t.setTravellingDate("12/3/23");
		  t.setTrain(t1);
		  
		  
		  List<Ticket> tir=new ArrayList<>();
		  tir.add(t);
		  

		  Passenger p=new Passenger();
		  p.setPassengerName("Aman");
	      p.setPassengerId(3);
		  p.setAge(26);
		  p.setTicket(tir);
		  
		  List<Passenger>pList=new ArrayList<>();
		  pList.add(p);
		  
		  
		  when(passengerService.getAllPassenger()).thenReturn(pList);
		  String json = mapper.writeValueAsString(p);
		  RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/passengers")
				  .content(json)
				  .contentType(MediaType.APPLICATION_JSON);
		  MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
		  String actualResponseBody = mvcResult.getResponse().getContentAsString();
		  JSONAssert.assertEquals("[{passengerId:3}]", actualResponseBody, false);
		
	}
	@Test
	@Order(3)
	public void update() throws Exception
	{
		
			  Train train=new Train();
			  train.setTrainId(2);
			  train.setTrainSource("Pune");
			  train.setCapacity(24);
			  train.setIsAvailable("true");
			  train.setTrainDestination("Mumbai");
			  
			  
			  List<Train>t1=new ArrayList<Train>();
			  t1.add(train);
			  
			  Ticket t=new Ticket();
			  t.setTicketId(9);
			  t.setTicketAmount(200f);
			  t.setSource("Pune");
			  t.setSeatAllotted(3);
			  t.setPassenger_Id(3);
			  t.setDestination("Nagpur");
			  t.setArrivalDate("12/3/23");
			  t.setTravellingDate("12/3/23");
			  t.setTrain(t1);
			  
			  
			  List<Ticket> tir=new ArrayList<>();
			  tir.add(t);
			  

			  Passenger p=new Passenger();
			  p.setPassengerName("Aman");
		      p.setPassengerId(3);
			  p.setAge(26);
			  p.setTicket(tir);
			  

			  
			  when(passengerService.saveOrUpdate(Mockito.any(Passenger.class))).thenReturn("Updated");
			  
			  String json= mapper.writeValueAsString(p);
			  
			  RequestBuilder requestBuilder = MockMvcRequestBuilders
			  .put("/passengers")
			  .content(json)
			  .contentType(MediaType.APPLICATION_JSON);
			  MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk())
			  .andReturn();
			  
			  String actualResponseBody = mvcResult.getResponse().getContentAsString();
			  String expected="Updated";
			  assertThat(actualResponseBody).isEqualToIgnoringWhitespace(expected);
	
	}
	
	@Test
	@Order(4)
	public void delete() throws Exception
	{
		Train train=new Train();
		  train.setTrainId(2);
		  train.setTrainSource("Pune");
		  train.setCapacity(24);
		  train.setIsAvailable("true");
		  train.setTrainDestination("Mumbai");
		  
		  
		  List<Train>t1=new ArrayList<Train>();
		  t1.add(train);
		  
		  Ticket t=new Ticket();
		  t.setTicketId(9);
		  t.setTicketAmount(200f);
		  t.setSource("Pune");
		  t.setSeatAllotted(3);
		  t.setPassenger_Id(3);
		  t.setDestination("Nagpur");
		  t.setArrivalDate("12/3/23");
		  t.setTravellingDate("12/3/23");
		  t.setTrain(t1);
		  
		  
		  List<Ticket> tir=new ArrayList<>();
		  tir.add(t);
		  

		  Passenger p=new Passenger();
		  p.setPassengerName("Aman");
	      p.setPassengerId(3);
		  p.setAge(26);
		  p.setTicket(tir);
		  
		  List<Passenger>pList=new ArrayList<>();
		  pList.add(p);
		  
		 
		  
		  when(passengerService.getAllPassenger()).thenReturn(pList);		  
		  String json= mapper.writeValueAsString(p);
		  
		  RequestBuilder requestBuilder = MockMvcRequestBuilders.delete("/passengers")
		  .content(json)
		  .contentType(MediaType.APPLICATION_JSON);
		  MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk())
		  .andReturn();
		  
		  String actualResponseBody = mvcResult.getResponse().getContentAsString();
		  String expected="Deleted";
		  assertThat(actualResponseBody).isEqualToIgnoringWhitespace(expected);
	}

}
