package com.javatpoint.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatpoint.model.Passenger;
import com.javatpoint.model.Ticket;
import com.javatpoint.model.Train;
import com.javatpoint.repository.PassengerRepository;
import com.javatpoint.repository.TicketRepository;
import com.javatpoint.repository.TrainRepository;

@Service
public class PassengerService {
	@Autowired
	PassengerRepository passengerRepository;

	@Autowired
	TicketRepository ticketRepository;
	@Autowired
	TrainRepository  trainrepository;

	// Getting all records
	public List<Passenger> getAllPassenger() {
		List<Passenger> passenger = new ArrayList<Passenger>();
		passengerRepository.findAll().forEach(passengers -> passenger.add(passengers));
		return passenger;

	}

	// Getting single record
	public Passenger getPassengerById(Integer id) {
		return passengerRepository.findById(id).get();
	}

	// Booking of ticket
	public String saveOrUpdate(Passenger p) 
	{
		
		List<Ticket> ticket = p.getTicket();
		System.out.println(p.getTicket().size());
		if (p.getTicket().size() >4) 
		{
			return "More that three ticket";
		} 
		else 
		{
			for (int i = 0; i < ticket.size(); i++)
			{
				Optional<Ticket> tic = ticketRepository.findById(ticket.get(i).getTicketId());
				if( p.getAge()>60)
				{
            	   float a=(ticket.get(i).getTicketAmount()*10)/100;
                ticket.get(i).setTicketAmount(ticket.get(i).getTicketAmount()-a);
               }
				if (tic.isPresent()) 
				{
					return "Ticket Already Booked";
				}
				
				
			
			
			}
			Passenger p1 = passengerRepository.save(p);
			
				 	List<String> n=trainrepository.Available();
				 System.out.println(n);
				 for(int j = 0; j < n.size();j++) {
					 if(n.get(j)=="false") {
						 ticketRepository.delete(ticket.get(j));
						 trainrepository.delete(null);
						 System.out.println(ticket.get(j));
					 }
				 }
			
			
			if (p1!= null) 
			{

				  return "Booking done Succesfully";
			}
			else 
			{
			return "Unsuccesful";
			}
		}
		
	}

	public void delete(Integer id) {
		passengerRepository.deleteById(id);
	}
	
	public void deleteAll(Passenger p) {
		passengerRepository.deleteAll();
	}

}
