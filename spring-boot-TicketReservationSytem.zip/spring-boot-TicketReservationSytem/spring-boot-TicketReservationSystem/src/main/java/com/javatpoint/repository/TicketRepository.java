package com.javatpoint.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.javatpoint.model.Ticket;

public interface TicketRepository extends CrudRepository<Ticket, Integer> 
{
	
	/*
	 * @Query("select t from Ticket t where ticketId= :ticketId") public Ticket
	 * FindTicket(Integer ticketId);
	 */
	
	Ticket findBySourceAndDestination(String source,String destination);

}
