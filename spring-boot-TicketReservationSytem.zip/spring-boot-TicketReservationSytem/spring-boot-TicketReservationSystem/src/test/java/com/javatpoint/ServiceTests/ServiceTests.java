package com.javatpoint.ServiceTests;

import static org.assertj.core.api.Assertions.assertThat;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.javatpoint.model.Passenger;
import com.javatpoint.model.Ticket;
import com.javatpoint.model.Train;
import com.javatpoint.repository.PassengerRepository;
import com.javatpoint.service.PassengerService;

@SpringBootTest

@TestMethodOrder(OrderAnnotation.class)
class ServiceTests {
	
	@Autowired
	private PassengerService passengerService;
	@Autowired
	private PassengerRepository passRepository;
	
	
	@Test
	@Order(1)
	//Posting
	  void testCreatePassengers()
	  {
		  Train train=new Train();
		  train.setTrainId(2);
		  train.setTrainSource("Pune");
		  train.setCapacity(24);
		  train.setIsAvailable("true");
		  train.setTrainDestination("Mumbai");
		  
		  
		  List<Train>t1=new ArrayList<>();
		  t1.add(train);
		  
		  Ticket t=new Ticket();
		  t.setTicketId(9);
		  t.setTicketAmount(200f);
		  t.setSource("Pune");
		  t.setSeatAllotted(3);
		  t.setPassenger_Id(3);
		  t.setDestination("Nagpur");
		  t.setArrivalDate("12/3/23");
		  t.setTravellingDate("12/3/23");
		  t.setTrain(t1);
		  
		  
		  List<Ticket> tir=new ArrayList<>();
		  tir.add(t);
		  
		  List<Passenger>pList=new ArrayList<>();
		  Passenger p=new Passenger();
		  p.setPassengerName("Aman");
	      p.setPassengerId(3);
		  p.setAge(26);
		  p.setTicket(tir);
		  
		  
		  
		  assertEquals("Booking done Succesfully",passengerService.saveOrUpdate(p) );
		  
	  }
	 @Test
	 @Order(2)
	  public void get()
	  {
		  Train train=new Train();
		  train.setTrainId(2);
		  train.setTrainSource("Pune");
		  train.setCapacity(24);
		  train.setIsAvailable("true");
		  train.setTrainDestination("Mumbai");
		  
		  
		  List<Train>t1=new ArrayList<>();
		  t1.add(train);
		  
		  Ticket t=new Ticket();
		  t.setTicketId(9);
		  t.setTicketAmount(200f);
		  t.setSource("Pune");
		  t.setSeatAllotted(3);
		  t.setPassenger_Id(3);
		  t.setDestination("Nagpur");
		  t.setArrivalDate("12/3/23");
		  t.setTravellingDate("12/3/23");
		  t.setTrain(t1);
		  
		  
		  List<Ticket> tir=new ArrayList<>();
		  tir.add(t);
		  Passenger p=new Passenger();
		  p.setPassengerName("Aman");
	      p.setPassengerId(3);
		  p.setAge(26);
		  p.setTicket(tir);
		  
		  passengerService.saveOrUpdate(p);
		  List<Passenger>passenger=passengerService.getAllPassenger();
		  assertThat(passenger).size().isGreaterThan(0);
		  
	  }
	  @Test
	  @Order(3)
	  public void delete()
	  {
		  Train train=new Train();
		  train.setTrainId(2);
		  train.setTrainSource("Pune");
		  train.setCapacity(24);
		  train.setIsAvailable("true");
		  train.setTrainDestination("Mumbai");
		  
		  
		  List<Train>t1=new ArrayList<>();
		  t1.add(train);
		  
		  Ticket t=new Ticket();
		  t.setTicketId(9);
		  t.setTicketAmount(200f);
		  t.setSource("Pune");
		  t.setSeatAllotted(3);
		  t.setPassenger_Id(3);
		  t.setDestination("Nagpur");
		  t.setArrivalDate("12/3/23");
		  t.setTravellingDate("12/3/23");
		  t.setTrain(t1);
		  
		  
		  List<Ticket> tir=new ArrayList<>();
		  tir.add(t);
		  Passenger p=new Passenger();
		  p.setPassengerName("Aman");
	      p.setPassengerId(3);
		  p.setAge(26);
		  p.setTicket(tir);
		  
		  passengerService.saveOrUpdate(p);
		  passengerService.delete(p.getPassengerId());
		  
		  assertThat(passRepository.existsById(3)).isFalse();
		  
	  }
}
