package com.javatpoint.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Ticket {
	
	

	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer ticketId;
	private String source;
	private String destination;
	private int seatAllotted;
	private String travellingDate;
	private String arrivalDate;
	private float ticketAmount;
	private int passenger_Id;
	
	@OneToMany(cascade= {CascadeType.ALL})
   List<Train> train;
	
	public Ticket() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Ticket(Integer ticketId, String source, String destination, int seatAllotted, String travellingDate,
			String arrivalDate, float ticketAmount, int passenger_Id, List<Train> train) {
		super();
		this.ticketId = ticketId;
		this.source = source;
		this.destination = destination;
		this.seatAllotted = seatAllotted;
		this.travellingDate = travellingDate;
		this.arrivalDate = arrivalDate;
		this.ticketAmount = ticketAmount;
		this.passenger_Id = passenger_Id;
		this.train = train;
	}

	public Integer getTicketId() {
		return ticketId;
	}

	public void setTicketId(Integer ticketId) {
		this.ticketId = ticketId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getSeatAllotted() {
		return seatAllotted;
	}

	public void setSeatAllotted(int seatAllotted) {
		this.seatAllotted = seatAllotted;
	}

	public String getTravellingDate() {
		return travellingDate;
	}

	public void setTravellingDate(String travellingDate) {
		this.travellingDate = travellingDate;
	}

	public String getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public float getTicketAmount() {
		return ticketAmount;
	}

	public void setTicketAmount(float ticketAmount) {
		this.ticketAmount = ticketAmount;
	}

	public int getPassenger_Id() {
		return passenger_Id;
	}

	public void setPassenger_Id(int passenger_Id) {
		this.passenger_Id = passenger_Id;
	}

	public List<Train> getTrain() {
		return train;
	}

	public void setTrain(List<Train> train) {
		this.train = train;
	}
	
	@Override
	public String toString() {
		return "Ticket [ticketId=" + ticketId + ", source=" + source + ", destination=" + destination
				+ ", seatAllotted=" + seatAllotted + ", travellingDate=" + travellingDate + ", arrivalDate="
				+ arrivalDate + ", ticketAmount=" + ticketAmount + ", passenger_Id=" + passenger_Id + ", train=" + train
				+ "]";
	}


}
