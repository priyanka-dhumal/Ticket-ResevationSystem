package com.javatpoint.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.javatpoint.model.Passenger;
import com.javatpoint.model.Ticket;

public interface PassengerRepository extends CrudRepository<Passenger, Integer>
{

	
	/*
	 * @Query("select t from Ticket t where ticketId= :ticketId") public Ticket
	 * FindTicket(Integer ticketId);
	 */

	

}
