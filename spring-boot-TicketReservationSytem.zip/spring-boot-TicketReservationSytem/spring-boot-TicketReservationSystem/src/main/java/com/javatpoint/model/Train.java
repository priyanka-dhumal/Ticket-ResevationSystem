package com.javatpoint.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Train {
	

	@Id
	private int trainId;
	private int capacity;
	private int noOfComparments;
	private String trainSource;
	private String trainDestination;
	private String isAvailable;
	public Train() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Train(int trainId, int capacity, int noOfComparments, String trainSource, String trainDestination,
			String isAvailable) {
		super();
		this.trainId = trainId;
		this.capacity = capacity;
		this.noOfComparments = noOfComparments;
		this.trainSource = trainSource;
		this.trainDestination = trainDestination;
		this.isAvailable = isAvailable;
	}
	public int getTrainId() {
		return trainId;
	}
	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public int getNoOfComparments() {
		return noOfComparments;
	}
	public void setNoOfComparments(int noOfComparments) {
		this.noOfComparments = noOfComparments;
	}
	public String getTrainSource() {
		return trainSource;
	}
	public void setTrainSource(String trainSource) {
		this.trainSource = trainSource;
	}
	public String getTrainDestination() {
		return trainDestination;
	}
	public void setTrainDestination(String trainDestination) {
		this.trainDestination = trainDestination;
	}
	public String getIsAvailable() {
		return isAvailable;
	}
	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}
	@Override
	public String toString() {
		return "Train [trainId=" + trainId + ", capacity=" + capacity + ", noOfComparments=" + noOfComparments
				+ ", trainSource=" + trainSource + ", trainDestination=" + trainDestination + ", isAvailable="
				+ isAvailable + "]";
	}
	
	
		
}
