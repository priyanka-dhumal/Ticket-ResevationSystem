package com.javatpoint;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.javatpoint.model.Passenger;
import com.javatpoint.repository.PassengerRepository;
import com.javatpoint.service.PassengerService;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class SpringBootRepositoryTests {
	@Autowired
	private PassengerRepository passRepository;
	

	@Test
	@Order(1)
	void create()
	{
		Passenger p=new Passenger();
		p.setPassengerName("Aman");
		p.setPassengerId(3);
		p.setAge(26);
		
		passRepository.save(p);
		
		
		assertNotNull(passRepository.findById(3).get());	

	}
	
	@Test
	@Order(2)
	void readData()
	{
		 List<Passenger> list=(List<Passenger>) passRepository.findAll();
		assertThat(list).size().isGreaterThan(0);
	}
	
	@Test
	@Order(3)
	void readSingleRecord()
	{
		Passenger p=passRepository.findById(3).get();
		assertEquals(3,p.getPassengerId());		
	}
	
	
	

	  @Test
	  @Order(4)
	  void updateRecords()
	  { Passenger p=passRepository.findById(3).get();
	  p.setPassengerName("Anupam"); passRepository.save(p);
	  assertNotEquals("Aman",passRepository.findById(3).get() ); }
	 
	 
	  @Test
	  @Order(5) 
	  void deleteRecord()
	  { 
	  passRepository.deleteById(3);
	  assertThat(passRepository.existsById(3)).isFalse(); }
	 
	  
	  
	 
	  
	  
}
