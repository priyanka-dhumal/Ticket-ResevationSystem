package com.javatpoint.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javatpoint.model.Passenger;
import com.javatpoint.model.Ticket;
import com.javatpoint.model.Train;
import com.javatpoint.repository.PassengerRepository;
import com.javatpoint.repository.TicketRepository;
import com.javatpoint.repository.TrainRepository;

@Service
public class TicketService 
{
	@Autowired
	TicketRepository ticketRepository;
	
	@Autowired
	TrainRepository trainRepository;
	
	
	public List<Ticket> getAllTickets(){
		List<Ticket> ticket =new ArrayList<Ticket>();
		ticketRepository.findAll().forEach(Ticket1 -> ticket.add(Ticket1));
		return ticket;
	}
	
	public List<Ticket> getAllTicket()
	{
		List<Ticket> ticket=new ArrayList<Ticket>();
		ticketRepository.findAll().forEach(ticket1 -> ticket.add(ticket1));
		return ticket;
	}
	
	public Ticket getById(Integer id)
	{
		return ticketRepository.findById(id).get();
	}
	//post
	public String saveOrUpdate(Ticket ticket)
	{
		
		//Checking capacity and availability of the train
		List<Train>train=ticket.getTrain();
		for(int i=0;i<train.size();i++)
		{
			Optional<Train> t=trainRepository.findById(train.get(i).getTrainId());
			if(t.isPresent())
			{
				ticketRepository.save(ticket);	
			}
		
		}
		
		return "Train capacity is full";
		//ticketRepository.save(ticket);
		
	}
	public void delete(Integer id)
	{
		ticketRepository.deleteById(id);
	}

}
